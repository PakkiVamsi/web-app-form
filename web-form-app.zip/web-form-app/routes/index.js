var express = require('express');
var router = express.Router();
var path = require('path');

/* GET home page. */




const taxRates = {
    'Alberta': 0.05,
    'British Columbia': 0.07,
    'Manitoba': 0.07,
    'New Brunswick': 0.15,
    'Newfoundland and Labrador': 0.15,
    'Nova Scotia': 0.15,
    'Ontario': 0.13,
    'Prince Edward Island': 0.15,
    'Quebec': 0.14975,
    'Saskatchewan': 0.11,
    'Northwest Territories': 0.05,
    'Nunavut': 0.05,
    'Yukon': 0.05
};


function validatePhoneNumber(phone) {
  const phoneRegex = /^\d{10}$/;
  return phoneRegex.test(phone);
}

function validateEmail(email) {
  const emailRegex = /\S+@\S+\.\S+/;
  return emailRegex.test(email);
}


router.get('/', function(req, res, next) {
  console.log(path.resolve(__dirname,'..') + '\\views\\index.html');
  res.render('index',{errors:[],formData:[]});
});


const products = [
    { id: 1, name: 'Product 1', price: 5 },
    { id: 2, name: 'Product 2', price: 7 }
  ];

  
router.post('/purchase', (req, res) => {
  console.log(req.body);
  // console.log("quantity" ,quantity);
  const { name, address, city, province, phone, email,quantity:quantity } = req.body;
  let errors = {};

  let selectedProducts ;
  if(req.body.products != undefined && req.body.products.length==1) selectedProducts=[req.body.products];
  else selectedProducts=req.body.products;

  console.log(selectedProducts);
  console.log()
  // console.log("quantity" ,quantity);
  const formData = {name ,address , city, province, phone, email ,selectedProducts,quantity };
  console.log(formData);
  console.log("selectedProducts" ,selectedProducts)


  if (!name) {
      errors.name = 'Name is required.';
  }
  if (!address) {
      errors.address = 'Address is required.';
  }
  if (!city) {
      errors.city = 'City is required.';
  }
  if (!province) {
      errors.province = 'Province is required.';
  }
  if (!phone) {
      errors.phone = 'Phone number is required.';
  } else if (!validatePhoneNumber(phone)) {
      errors.phone = 'Invalid phone number format.';
  }
  if (!email) {
      errors.email = 'Email is required.';
  } else if (!validateEmail(email)) {
      errors.email = 'Invalid email format.';
  }

  console.log(selectedProducts);
  if (selectedProducts==undefined || selectedProducts.length === 0) {
      errors.selectedProducts = 'Please select at least one product.';
  } else {
      selectedProducts.forEach((productId,index)=>{
        console.log("ijij");
        console.log(quantity, productId,quantity[parseInt(productId)-1]);
        if(quantity[parseInt(productId)-1] == 0 ){
            errors.selectedProducts = 'Please increase the quantity.';
            console.log("jj");
            // console.log(product);
        }
                
      })
  }

  if (Object.keys(errors).length > 0) {
      return res.status(400).render('index', { errors,formData});
  }
  console.log(errors,formData);
  
  let totalAmount = 0;
  let receipt = '<html><head><style> h1,h2,h3,p{text-align:center}.container{max-width:600px;margin:0px auto;padding:20px;background-color:#fff;border-radius:5px;box-shadow:0 0 10px rgba(0,0,0,.1)}h1{color:#87cefa}form{margin-top:20px;padding:20px}label{margin-top:50px;font-weight:700}input[type=email],input[type=number],input[type=text]{width:100%;padding:10px;margin-bottom:10px;border:1px solid #ccc;border-radius:3px;box-sizing:border-box}input[type=submit]{width:100%;padding:10px;margin-top:10px;background-color:#007bff;color:#fff;border:none;border-radius:3px;cursor:pointer}input[type=submit]:hover{background-color:#0056b3}.error{color:red;font-size:.8em}</style></head><body>';

  // return res.status(400).send(`<h1>Hey</h1>`);
  console.log(selectedProducts);
  products.forEach((product, index) => {
      console.log("st");
      console.log(product,index);
      console.log("send");
      const fetchedProductId = selectedProducts.find(p => parseInt(p) == product.id);

      if(fetchedProductId!=undefined){
        const prodQuantity =parseInt(quantity[fetchedProductId-1]);
        totalAmount += product.price * prodQuantity;
        receipt += `<div class='container' ><p>${product.name} x ${prodQuantity}: ${product.price * prodQuantity}</p>`;
      }
    
      

      console.log(totalAmount);
  });
  console.log("products", products , " hi");
  console.log("hi");

  if (totalAmount < 10) {
      errors.totalAmount = 'Minimum purchase should be $10.';
      return res.status(400).render('index', { errors ,formData});
  }

  receipt += `<p>Total Amount: $${totalAmount.toFixed(2)}</p>`;

  const provinceTaxRate = taxRates[province];
  const taxAmount = totalAmount * provinceTaxRate;
  totalAmount += taxAmount;

  console.log(taxAmount); 
  receipt += `<p>Sales Tax (${province}): $${taxAmount.toFixed(2)}</p>`;
  receipt += `<p>Total Amount (including tax): $${totalAmount.toFixed(2)}</p>`;


  let TotalReceipt =`<h1>Receipt</h1><p>Name: ${name}</p><p>Address: ${address}</p><p>City: ${city}</p><p>Province: ${province}</p><p>Phone: ${phone}</p><p>Email: ${email}</p><h3>Products Purchased:</h3>${receipt} </div></body></html>`
  return res.status(400).send(TotalReceipt);

  




  // res.send(receipt);
  
});



module.exports = router;
